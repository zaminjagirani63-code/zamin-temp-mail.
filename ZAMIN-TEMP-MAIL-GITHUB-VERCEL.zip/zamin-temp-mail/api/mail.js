// Vercel serverless function: /api/mail
// Public GrabMail API proxy. No API key is required for public domains.
const BASE = 'https://grabmail.io/api/v1';

function send(res, status, body) {
  res.status(status).setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.end(JSON.stringify(body));
}
function validAddress(address) {
  return typeof address === 'string' &&
    address.length <= 120 &&
    /^[a-zA-Z0-9._+-]+@grabmail\.io$/i.test(address);
}
function validId(id) {
  return typeof id === 'string' && id.length > 0 && id.length <= 160 &&
    /^[a-zA-Z0-9_-]+$/.test(id);
}
module.exports = async (req, res) => {
  const method = req.method || 'GET';
  const params = method === 'DELETE' ? (req.query || {}) : (req.query || {});
  const action = params.action;
  const address = params.address;
  if (!['GET','DELETE'].includes(method)) {
    res.setHeader('Allow','GET, DELETE');
    return send(res,405,{error:'Method not allowed'});
  }
  if (!validAddress(address)) return send(res,400,{error:'Please provide a valid @grabmail.io address.'});

  let url;
  if (action === 'inbox' && method === 'GET') {
    url = new URL(BASE + '/mailbox');
    url.searchParams.set('address',address);
    url.searchParams.set('limit','50');
  } else if (action === 'read' && method === 'GET') {
    if (!validId(params.id)) return send(res,400,{error:'Invalid message ID.'});
    url = new URL(BASE + '/message/' + encodeURIComponent(params.id));
    url.searchParams.set('mailbox',address);
  } else if (action === 'delete' && method === 'DELETE') {
    if (!validId(params.id)) return send(res,400,{error:'Invalid message ID.'});
    url = new URL(BASE + '/message/' + encodeURIComponent(params.id));
    url.searchParams.set('mailbox',address);
  } else {
    return send(res,400,{error:'Unknown action or incorrect HTTP method.'});
  }

  try {
    const upstream = await fetch(url.toString(), {
      method,
      headers: { 'Accept':'application/json' }
    });
    const raw = await upstream.text();
    let data;
    try { data = JSON.parse(raw); } catch { data = {error:'The email provider returned an unreadable response.'}; }
    return send(res,upstream.status,data);
  } catch (error) {
    return send(res,502,{error:'Could not connect to GrabMail. Please try again.'});
  }
};
